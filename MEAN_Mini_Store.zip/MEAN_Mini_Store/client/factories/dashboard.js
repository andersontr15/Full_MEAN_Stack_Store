orders_and_customers_app.factory('DashboardFactory', function($http){
			var factory = {};
			return factory;
});